import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from awsglue.dynamicframe import DynamicFrame


## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME', 'parquet_path'])

# Create Glue Context and spark session
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Input: Database and table name from Catalog
db_name = "weblogs_dev"
table_name = "raw"

# Output: S3 and temp directories
parquet_output_path = args['parquet_path']

# Create dynamic frame from catalog
datasource0 = glueContext.create_dynamic_frame.from_catalog(database = db_name, table_name = table_name, transformation_ctx = "datasource0")

# Convert to Spark DataFrame 
df = datasource0.toDF()

new_df = df.select(df.clientip, df.ident, df.auth, df.timestamp, df.verb, df.request, df.httpversion, df.response, df.bytes, df.referrer, df.agent)

# Cast the datetime column to timestamp
#ts_df = new_df.withColumn("dt", unix_timestamp(df.timestamp, "yyyy-MM-dd HH:mm:ss").cast('timestamp').cast("double").cast("timestamp")).drop(df.timestamp)
ts_df = new_df.withColumn("dt", unix_timestamp(df.timestamp, "yyyy-MM-dd HH:mm:ss").cast("timestamp")).drop(df.timestamp)


# Cast the response column to integer
rsp_df = ts_df.withColumn("rsp", ts_df.response.cast('integer')).drop("response").withColumnRenamed('rsp', 'response')

# Cast the bytes column to integer
parsed_df = rsp_df.withColumn("bts", rsp_df.bytes.cast('integer')).drop("bytes").withColumnRenamed('bts', 'bytes')

# Convert back to Dataframe
mappedDF = DynamicFrame.fromDF(parsed_df, glueContext, "mappedDF")


datasink4 = glueContext.write_dynamic_frame.from_options(frame = mappedDF, connection_type = "s3", connection_options = {"path": parquet_output_path}, format = "parquet", transformation_ctx = "datasink4")

job.commit()